# PDF Editor 3.0 for Android

Same idea as the Windows version: edit text, add text/images/shapes, manage pages. Everything runs on the phone.
The PDF engine is **MuPDF (WebAssembly)**, packaged into an installable Android app with **Capacitor**.

## Get the APK (about 10 minutes, no software to install)

You need a free GitHub account. The APK is built on GitHub's servers.

1. On github.com create a **new repository** (private is fine).
2. Upload **everything in this folder** to it (drag the files in with *Add file → Upload files*).
   Make sure the hidden folder `.github/workflows/build-apk.yml` is included. Easiest: unzip, then drag the
   *contents* of the folder, including `.github`, into the upload page. (Or use git: `git init`, `git add -A`,
   `git commit`, `git push`.)
3. Open the **Actions** tab → **Build Android APK** → **Run workflow**. It also starts on its own after the upload.
4. When it turns green (5–10 min) open the run and download **PDF-Editor-APK** at the bottom. Unzip it:
   inside is `app-debug.apk`.
5. Copy `app-debug.apk` to your phone and tap it. Android will ask to allow *Install unknown apps* for your
   file manager/browser: allow it. Play Protect may warn that the app is unrecognised (it is a debug-signed
   build of your own app): choose *Install anyway*.

If the build fails, open the failed step in the Actions log and send me the red error text.

## Using the app
* **Open PDF** (welcome screen or ⋮ menu). Pinch to zoom, scroll with one finger.
* **Edit text** tool: tap a line, change it, **Apply**. Also: **Select** → tap text → *Edit*, or double-tap it.
* **Add text**: tap where it should go. **Image**: tap where it should go, pick a picture.
* **Shapes**: pick rectangle / ellipse / line, then drag on the page. Shapes can be selected, moved, resized, deleted.
* **Select** tool: tap an object, drag it to move; the bar offers Smaller/Larger, Copy, Cut, Paste, Delete.
* ⋮ menu: Find, Pages (rotate, add blank, move, extract, import, delete), Bookmarks, Save as new file, Share, Paste,
  Fit width, edit by line/paragraph, Document properties, Optimize, Import font, theme.
* **Open**: *Open PDF* uses Android's file picker. You can also open a PDF from **any other app** (Files, WhatsApp, Gmail,
  Drive…) with *Open with → PDF Editor*; if the app is already running the new file opens in it.
* **Save** (the download button): overwrites the **same file** you opened. If the other app only allows reading, the app
  tells you and offers *Save as new file* instead. For a brand-new blank PDF, Save asks where to put it.
* **Save as new file…** (⋮ menu): Android's "save" dialog, where you pick the folder and file name. Afterwards the
  document is linked to that new file, so Save writes there. **Share a copy…** sends a copy through the share sheet.
* **Bookmarks** (⋮ menu): shows the PDF's bookmarks (tap *Go* to jump). Add a bookmark for the page you are viewing,
  rename it or change its page, move it up/down, nest or un-nest it, delete it, then tap *Save bookmarks*.
* Back button: closes dialogs first; if you have unsaved changes it asks before leaving.

## The character fix (same root cause as on Windows)
Most PDFs embed only the letters their text uses, so J, Z, !, # … may not exist in the document's font. Every line
you edit or add is rewritten with a **complete embedded font** (bundled Liberation / DejaVu), so every letter,
number, punctuation mark and symbol the font contains works, displays, saves and survives reopening.
Menu → *Import font* adds your own .ttf/.otf for the current session.

## Keeping the original font (new in this build)
Android phones don't have Courier New, Arial etc. (and those fonts can't be bundled), so instead:
* Every character that the PDF's **own embedded font already contains** is written with that very same font, so edited
  text looks identical to the original (a Courier New receipt stays Courier New).
* Only characters the original font lacks (for example J, Z, !, # in a subset font) use a bundled full font. For
  Courier-style text that fallback is **FreeMono** (thin, Courier-like), so the substitutes blend in.
* If you pick a different font, bold or italic in the editor, your choice is used for the whole line.
* Lines that were already saved with another font (for example by an older build) can't be restored; edit them again
  and choose *FreeMono* (Courier-style), or edit from the original, unedited PDF.

## Differences from the Windows version
* Shapes are PDF *annotations* (so they can be moved/deleted on a touch screen) rather than page content.
* No printing.
* Undo history keeps the last 25 steps (phone memory).
* Same limits as Windows: text is edited line by line (or paragraph by paragraph), keeps original line breaks,
  and uses a full font that can differ slightly from an unusual original typeface.

## What was tested (and what was not)
Tested: the engine in Node (all printable ASCII typed into a PDF whose font lacks J/Z/!/#…, saved, reopened, at page
rotations 0/90/180/270; moving/deleting/adding objects; page operations; password PDFs; read-only detection) and the
whole interface in headless Firefox at a phone-sized window (loading, editing with the problem characters, add text,
select + drag, shapes, undo/redo, search, page manager, zoom). The Android project was generated and synced
successfully with all three plugins.
The new file features were tested in the browser against a stand-in for the native plugin (open-with at launch and
while running, Save in place, read-only original, Save as new file, cancelling the dialog, the file picker, and the full
bookmark add / nest / reorder / rename / delete / save cycle, with the saved bytes re-read independently). The native
Java plugin (`resources/android-src/PdfFilesPlugin.java`) compiles cleanly against the real Android API with
Capacitor's exact method signatures, and the manifest patch was checked on a freshly generated project.
**Not tested:** the APK build itself (my environment cannot reach the Android SDK), and anything on a real Android
device: the real file dialogs, "Open with" from other apps, overwriting files in different storage providers
(Drive, Downloads, SD card), pinch-to-zoom with real fingers, the share sheet, memory use on very large PDFs.
Please try it and tell me what you see.

## Licences
MuPDF is AGPL-3.0 (source of this app is in this folder, which satisfies the source requirement for personal use).
Liberation fonts: SIL OFL. DejaVu fonts: free licence. FreeMono (GNU FreeFont): GPL-3.0-or-later with the font exception (documents you make with it are not affected). Capacitor: MIT.
