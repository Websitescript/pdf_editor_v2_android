package com.pdfeditor.mobile;

import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;
import android.util.Base64;

import androidx.activity.result.ActivityResult;

import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.ActivityCallback;
import com.getcapacitor.annotation.CapacitorPlugin;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

/**
 * Android Storage Access Framework bridge for the PDF editor:
 *  pick()            choose a PDF (read + write access, remembered)
 *  read({uri})       read a PDF by content:// uri
 *  write({uri,data}) overwrite that same file in place
 *  saveAs({name,data}) "Save as new file" dialog
 *  getLaunchFile() / event "fileOpened"   PDFs opened through "Open with"
 * File contents travel as base64 strings.
 */
@CapacitorPlugin(name = "PdfFiles")
public class PdfFilesPlugin extends Plugin {

    private static boolean launchHandled = false;

    private String displayName(Uri uri) {
        String name = null;
        Cursor c = null;
        try {
            c = getContext().getContentResolver().query(uri, new String[] { OpenableColumns.DISPLAY_NAME }, null, null, null);
            if (c != null && c.moveToFirst()) {
                name = c.getString(0);
            }
        } catch (Exception ignored) {
            // fall through to the path fallback
        } finally {
            if (c != null) {
                c.close();
            }
        }
        if (name == null || name.length() == 0) {
            name = uri.getLastPathSegment();
        }
        if (name == null || name.length() == 0) {
            name = "document.pdf";
        }
        return name;
    }

    private String readBase64(Uri uri) throws IOException {
        InputStream in = getContext().getContentResolver().openInputStream(uri);
        if (in == null) {
            throw new IOException("cannot open file");
        }
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[65536];
            int n;
            while ((n = in.read(buf)) > 0) {
                out.write(buf, 0, n);
            }
            return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
        } finally {
            in.close();
        }
    }

    private void writeBase64(Uri uri, String data) throws IOException {
        byte[] bytes = Base64.decode(data, Base64.DEFAULT);
        // "wt" = write + truncate, so a shorter file does not keep stale bytes
        OutputStream out = getContext().getContentResolver().openOutputStream(uri, "wt");
        if (out == null) {
            throw new IOException("cannot open file for writing");
        }
        try {
            out.write(bytes);
            out.flush();
        } finally {
            out.close();
        }
    }

    private JSObject describe(Uri uri, boolean withData) throws IOException {
        JSObject ret = new JSObject();
        ret.put("uri", uri.toString());
        ret.put("name", displayName(uri));
        if (withData) {
            ret.put("data", readBase64(uri));
        }
        return ret;
    }

    private static boolean isPdfIntent(Intent intent) {
        if (intent == null || intent.getData() == null) {
            return false;
        }
        String action = intent.getAction();
        return Intent.ACTION_VIEW.equals(action) || Intent.ACTION_EDIT.equals(action);
    }

    // ------------------------------------------------------------------ pick

    @PluginMethod
    public void pick(PluginCall call) {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION
                | Intent.FLAG_GRANT_WRITE_URI_PERMISSION
                | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        startActivityForResult(call, intent, "pickResult");
    }

    @ActivityCallback
    private void pickResult(PluginCall call, ActivityResult result) {
        if (call == null) {
            return;
        }
        Intent data = result.getData();
        if (result.getResultCode() != Activity.RESULT_OK || data == null || data.getData() == null) {
            call.reject("cancelled", "CANCELLED");
            return;
        }
        Uri uri = data.getData();
        try {
            int flags = data.getFlags() & (Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
            getContext().getContentResolver().takePersistableUriPermission(uri, flags);
        } catch (Exception ignored) {
            // permission is still valid for this session
        }
        try {
            call.resolve(describe(uri, true));
        } catch (Exception e) {
            call.reject("Could not read the file: " + e.getMessage());
        }
    }

    // ------------------------------------------------------------ read / write

    @PluginMethod
    public void read(PluginCall call) {
        String u = call.getString("uri");
        if (u == null) {
            call.reject("uri is required");
            return;
        }
        try {
            call.resolve(describe(Uri.parse(u), true));
        } catch (Exception e) {
            call.reject("Could not read the file: " + e.getMessage());
        }
    }

    @PluginMethod
    public void write(PluginCall call) {
        String u = call.getString("uri");
        String data = call.getString("data");
        if (u == null || data == null) {
            call.reject("uri and data are required");
            return;
        }
        try {
            Uri uri = Uri.parse(u);
            writeBase64(uri, data);
            call.resolve(describe(uri, false));
        } catch (SecurityException e) {
            call.reject("This file cannot be overwritten from here.", "NOT_WRITABLE");
        } catch (Exception e) {
            call.reject("Could not write the file: " + e.getMessage(), "WRITE_FAILED");
        }
    }

    // ----------------------------------------------------------------- save as

    @PluginMethod
    public void saveAs(PluginCall call) {
        String name = call.getString("name", "document.pdf");
        Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("application/pdf");
        intent.putExtra(Intent.EXTRA_TITLE, name);
        startActivityForResult(call, intent, "saveAsResult");
    }

    @ActivityCallback
    private void saveAsResult(PluginCall call, ActivityResult result) {
        if (call == null) {
            return;
        }
        Intent data = result.getData();
        if (result.getResultCode() != Activity.RESULT_OK || data == null || data.getData() == null) {
            call.reject("cancelled", "CANCELLED");
            return;
        }
        Uri uri = data.getData();
        String content = call.getString("data");
        if (content == null) {
            call.reject("data is required");
            return;
        }
        try {
            writeBase64(uri, content);
            call.resolve(describe(uri, false));
        } catch (Exception e) {
            call.reject("Could not save the file: " + e.getMessage(), "WRITE_FAILED");
        }
    }

    // ------------------------------------------------------------- "Open with"

    @PluginMethod
    public void getLaunchFile(PluginCall call) {
        JSObject ret = new JSObject();
        Intent intent = getActivity().getIntent();
        if (!launchHandled && isPdfIntent(intent)) {
            ret.put("uri", intent.getData().toString());
        }
        launchHandled = true;
        call.resolve(ret);
    }

    @Override
    protected void handleOnNewIntent(Intent intent) {
        super.handleOnNewIntent(intent);
        if (isPdfIntent(intent)) {
            JSObject ret = new JSObject();
            ret.put("uri", intent.getData().toString());
            notifyListeners("fileOpened", ret, true);
        }
    }
}
