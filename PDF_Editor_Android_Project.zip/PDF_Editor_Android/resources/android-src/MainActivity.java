package com.pdfeditor.mobile;

import android.os.Bundle;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {

    @Override
    public void onCreate(Bundle savedInstanceState) {
        // custom plugins must be registered before super.onCreate
        registerPlugin(PdfFilesPlugin.class);
        super.onCreate(savedInstanceState);
    }
}
