"""Adds the native PdfFiles plugin and the 'Open with' PDF handlers to the generated Android project."""
import pathlib, re, shutil, sys

root = pathlib.Path("android/app/src/main")
pkg_dir = root / "java" / "com" / "pdfeditor" / "mobile"
pkg_dir.mkdir(parents=True, exist_ok=True)
for f in pathlib.Path("resources/android-src").glob("*.java"):
    shutil.copy(f, pkg_dir / f.name)          # MainActivity.java is replaced, PdfFilesPlugin.java is added
    print("copied", f.name)

manifest = root / "AndroidManifest.xml"
xml = manifest.read_text(encoding="utf-8")
FILTERS = """
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:mimeType="application/pdf" />
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.EDIT" />
                <category android:name="android.intent.category.DEFAULT" />
                <data android:mimeType="application/pdf" />
            </intent-filter>
"""
if 'android.intent.action.VIEW' in xml:
    print("manifest already patched")
else:
    # the first </activity> closes MainActivity in the Capacitor template
    new, n = re.subn(r"(\s*</activity>)", FILTERS + r"\1", xml, count=1)
    if n != 1:
        sys.exit("Could not find </activity> in AndroidManifest.xml")
    manifest.write_text(new, encoding="utf-8")
    print("manifest patched")
